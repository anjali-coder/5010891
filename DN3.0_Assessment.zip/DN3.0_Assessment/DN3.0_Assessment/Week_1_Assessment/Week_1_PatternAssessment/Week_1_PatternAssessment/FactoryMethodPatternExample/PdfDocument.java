
// PdfDocument.java
public interface PdfDocument {
    void create();
}
