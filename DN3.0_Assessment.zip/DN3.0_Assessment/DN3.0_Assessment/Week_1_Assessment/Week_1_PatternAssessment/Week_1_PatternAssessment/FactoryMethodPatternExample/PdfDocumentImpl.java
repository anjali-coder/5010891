

// PdfDocumentImpl.java
public class PdfDocumentImpl implements PdfDocument {
    @Override
    public void create() {
        System.out.println("Creating PDF Document");
    }
}
