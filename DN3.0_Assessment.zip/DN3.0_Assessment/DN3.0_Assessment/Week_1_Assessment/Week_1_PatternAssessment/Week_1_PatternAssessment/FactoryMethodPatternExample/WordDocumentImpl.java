// WordDocumentImpl.java
public class WordDocumentImpl implements WordDocument {
    @Override
    public void create() {
        System.out.println("Creating Word Document");
    }
}
