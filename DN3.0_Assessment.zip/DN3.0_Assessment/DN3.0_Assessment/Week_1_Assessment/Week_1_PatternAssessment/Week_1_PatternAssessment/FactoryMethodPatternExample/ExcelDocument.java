

// ExcelDocument.java
public interface ExcelDocument {
    void create();
}
