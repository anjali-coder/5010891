

// WordDocument.java
public interface WordDocument {
    void create();
}
